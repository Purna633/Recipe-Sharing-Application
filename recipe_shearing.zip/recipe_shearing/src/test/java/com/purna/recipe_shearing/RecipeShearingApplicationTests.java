package com.purna.recipe_shearing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RecipeShearingApplicationTests {

	@Test
	void contextLoads() {
	}

}
