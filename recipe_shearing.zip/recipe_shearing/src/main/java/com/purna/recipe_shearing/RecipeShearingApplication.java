package com.purna.recipe_shearing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipeShearingApplication {

	public static void main(String[] args) {
		SpringApplication.run(RecipeShearingApplication.class, args);
	}

}
